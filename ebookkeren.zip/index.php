<?php
//settings
$cache_ext  = '.html'; //file extension
$cache_time     = 43200;  //Cache file expires after these seconds (1 hour = 3600 sec) (8 hour = 28800 sec) (12 hour = 43200 sec)
$cache_folder   = 'cache/'; //folder to store Cache files
$ignore_pages   = array('', '');

$dynamic_url    = 'http://'.$_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . $_SERVER['QUERY_STRING']; // requested dynamic page (full url)
$cache_file     = $cache_folder.md5($dynamic_url).$cache_ext; // construct a cache file
$ignore = (in_array($dynamic_url,$ignore_pages))?true:false; //check if url is in ignore list

if (!$ignore && file_exists($cache_file) && time() - $cache_time < filemtime($cache_file)) { //check Cache exist and it's not expired.
    ob_start('ob_gzhandler'); //Turn on output buffering, "ob_gzhandler" for the compressed page with gzip.
    readfile($cache_file); //read Cache file
    echo '<!-- cached page - '.date('l jS \of F Y h:i:s A', filemtime($cache_file)).', Page : '.$dynamic_url.' -->';
    ob_end_flush(); //Flush and turn off output buffering
    exit(); //no need to proceed further, exit the flow.
}
//Turn on output buffering with gzip compression.
ob_start('ob_gzhandler');
?>
<?php include('siteconfig.php'); ?>
<!doctype html>
<html>
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<!-- Meta -->
		
		<meta name="viewport" content="width=device-width">
		<title><?php echo $homepage_title; ?></title>
		<meta name="description" content="<?php echo $homepage_desc; ?>" />
		<meta name="keywords" content="<?php echo $site_keywords; ?>" />
		<meta property="og:site_name" content="<?php echo $site_title; ?>"/>
		<meta property="og:type" content="website"/>
		<meta property="og:title" content="<?php echo $homepage_title; ?>"/>
		<meta property="og:description" content="<?php echo $homepage_desc; ?>"/>
		<!-- CSS and Scripts -->
		<?php include 'includes/headscripts.php'; ?>
		<script type="text/javascript" src="<?php echo $site_url;?>/js/jquery.jcarousel.min.js"></script>
		<?php include 'ads/head_code.php'; ?>
    </head>
<body class="whiteback">
<?php include 'includes/header.php'; ?>
<?php
function cano($s){
	$s = $output = trim(preg_replace(array("`'`", "`[^a-z0-9]+`"),  array("", "-"), strtolower($s)), "-");
	return $s;
}
?> 

<script>
jQuery(document).ready(function($){
if(jQuery().jcarousel) {
	// Featured Carousel - Horizontal 
	$(window).bind('load resize', function(){
		
		$('.fcarousel-6').deCarousel();
		$('.fcarousel-5').deCarousel();
	});
	// games carousel
	$('.jcarousel').jcarousel({
        wrap: 'circular'
    });
	$('.jcarousel').jcarouselAutoscroll({
	target: '+=3',
	interval: 4000,
    autostart: true
	});
		
	// Featured Carousel - Vertical 
	$('.carousel-clip').jcarousel({
		vertical: true,
		wrap: 'circular'
	});
	$('.carousel-prev').jcarouselControl({target: '-=4'});
	$('.carousel-next').jcarouselControl({target: '+=4'});
}
});
</script>

<div class="container" style="margin-bottom:20px;">
<div class="pagetitle" style="clear: both;">
<h1><center>Top Populare eBooks</center></h1>
</div>
<div class="pageresults">
<ul class="page-itemlist">
<?php
$string = file_get_contents('https://itunes.apple.com/'.$site_country.'/rss/toppaidebooks/limit=25/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';

foreach ($xml->entry as $val) {
    
	// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	
	$bigimage = preg_replace('/170x170/ms', "270x270", $val->imimage[2]);
	
    $rssresults .= '<li class="page-item"><div class="pagethumb"><a href="'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'"><img data-src="'.$bigimage.'" src="'.$site_url.'/images/loading.svg" alt="'.$val->imname.'"></a></div>
	<div class="info"><h3><a href="'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'">'.$val->imname.'</a></h3>
		<h4>'.$val->impublisher.'</h4>
		<h4 class="genretit">'.$val->category->attributes()->label.'</h4>
		</div>
	</li>';
   
}
echo $rssresults;

?>
</ul>
</div>
</div>

<div class="container" style="margin-bottom:20px;">
<div class="pagetitle" style="clear: both;">
<h1><center>Top Audiobooks</center></h1>
</div>
<div class="pageresults">
<ul class="page-itemlist">
<?php
$string = file_get_contents('https://itunes.apple.com/'.$site_country.'/rss/topaudiobooks/limit=25/explicit=true/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';

foreach ($xml->entry as $val) {
    
	// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	
	$bigimage = preg_replace('/170x170/ms', "180x180", $val->imimage[2]);
	
    $rssresults .= '<li class="page-item audiob"><div class="pagethumb"><a href="'.$site_url.'/audiobook/'.$musicid[0].'/'.cano($val->imname).'"><img data-src="'.$bigimage.'" src="'.$site_url.'/images/loading.svg" alt="'.$val->imname.'"></a></div>
	<div class="info"><h3><a href="'.$site_url.'/audiobook/'.$musicid[0].'/'.cano($val->imname).'">'.$val->imname.'</a></h3>
		<h4>'.$val->imartist.'</h4>
		<h4 class="genretit">'.$val->category->attributes()->label.'</h4>
		</div>
	</li>';
   
}
echo $rssresults;

?>
</ul>
</div>
</div>

<div class="container" style="margin-bottom:20px;">
<div class="pagetitle" style="clear: both;">
<h1><center>Top Text Ebooks</center></h1>
</div>
<div class="pageresults">
<ul class="page-itemlist">
<?php
$string = file_get_contents('https://itunes.apple.com/'.$site_country.'/rss/toptextbooks/limit=25/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';

foreach ($xml->entry as $val) {
    
	// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	
	$bigimage = preg_replace('/170x170/ms', "270x270", $val->imimage[2]);
	
    $rssresults .= '<li class="page-item"><div class="pagethumb"><a href="'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'"><img data-src="'.$bigimage.'" src="'.$site_url.'/images/loading.svg" alt="'.$val->imname.'"></a></div>
	<div class="info"><h3><a href="'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'">'.$val->imname.'</a></h3>
		<h4>'.$val->impublisher.'</h4>
		<h4 class="genretit">'.$val->category->attributes()->label.'</h4>
		</div>
	</li>';
   
}
echo $rssresults;

?>
</ul>
</div>
</div>

<div class="container" style="margin-bottom:20px;">
<div class="pagetitle" style="clear: both;">
<h1><center>Top Free eBooks</center></h1>
</div>
<div class="pageresults">
<ul class="page-itemlist">
<?php
$string = file_get_contents('https://itunes.apple.com/'.$site_country.'/rss/topfreeebooks/limit=25/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';

foreach ($xml->entry as $val) {
    
	// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	
	$bigimage = preg_replace('/170x170/ms', "270x270", $val->imimage[2]);
	
    $rssresults .= '<li class="page-item"><div class="pagethumb"><a href="'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'"><img data-src="'.$bigimage.'" src="'.$site_url.'/images/loading.svg" alt="'.$val->imname.'"></a></div>
	<div class="info"><h3><a href="'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'">'.$val->imname.'</a></h3>
		<h4>'.$val->impublisher.'</h4>
		<h4 class="genretit">'.$val->category->attributes()->label.'</h4>
		</div>
	</li>';
   
}
echo $rssresults;

?>
</ul>
</div>
</div>

<!--end col-md-6 -->
<script src="<?php echo $site_url;?>/js/imglazyload.js"></script>
<script>
			//lazy loading
			$('.page-itemlist img').imgLazyLoad({
				// jquery selector or JS object
				container: window,
				// jQuery animations: fadeIn, show, slideDown
				effect: 'fadeIn',
				// animation speed
				speed: 600,
				// animation delay
				delay: 400,
				// callback function
				callback: function(){}
			});
</script>
<script>
$(document).ready(function(){

	// hide #back-top first
	$("#back-top").hide();
	
	// fade in #back-top
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 200) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});

});
</script>
<?php include 'includes/footer.php'; ?>
</body>
</html>
<?php
######## Your Website Content Ends here #########

if (!is_dir($cache_folder)) { //create a new folder if we need to
    mkdir($cache_folder);
}
if(!$ignore){
    $fp = fopen($cache_file, 'w');  //open file for writing
    fwrite($fp, ob_get_contents()); //write contents of the output buffer in Cache file
    fclose($fp); //Close file pointer
}
ob_end_flush(); //Flush and turn off output buffering

?>