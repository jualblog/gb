<?php include('siteconfig.php'); ?>
<?php
function cano($s){
	$s = $output = trim(preg_replace(array("`'`", "`[^a-z0-9]+`"),  array("", "-"), strtolower($s)), "-");
	return $s;
}
?> 

<script>
jQuery(document).ready(function($){
if(jQuery().jcarousel) {
	// Featured Carousel - Horizontal 
	$(window).bind('load resize', function(){
		
		$('.fcarousel-6').deCarousel();
		$('.fcarousel-5').deCarousel();
	});
	// games carousel
	$('.jcarousel').jcarousel({
        wrap: 'circular'
    });
	$('.jcarousel').jcarouselAutoscroll({
	target: '+=3',
	interval: 4000,
    autostart: true
	});
		
	// Featured Carousel - Vertical 
	$('.carousel-clip').jcarousel({
		vertical: true,
		wrap: 'circular'
	});
	$('.carousel-prev').jcarouselControl({target: '-=4'});
	$('.carousel-next').jcarouselControl({target: '+=4'});
}
});
</script>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10078/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10079/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10080/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10081/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10082/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10083/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10084/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10085/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10086/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10087/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10088/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10089/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10090/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10091/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10092/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10093/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10094/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10095/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10096/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10097/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10098/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10099/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10100/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10101/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10102/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10103/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10104/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10105/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10106/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10107/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10108/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10109/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10110/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10111/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10112/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10113/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10114/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10115/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10116/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10117/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10118/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10119/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10120/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10121/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10122/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10123/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10124/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10125/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10126/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10127/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
$culun .= '</urlset>';
// show 
echo $culun;
// and save to file 
file_put_contents('sitemap_03.xml', $culun);
?>