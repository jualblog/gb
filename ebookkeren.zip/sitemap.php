<?php include('siteconfig.php'); ?>
<?php
function cano($s){
	$s = $output = trim(preg_replace(array("`'`", "`[^a-z0-9]+`"),  array("", "-"), strtolower($s)), "-");
	return $s;
}
?> 

<script>
jQuery(document).ready(function($){
if(jQuery().jcarousel) {
	// Featured Carousel - Horizontal 
	$(window).bind('load resize', function(){
		
		$('.fcarousel-6').deCarousel();
		$('.fcarousel-5').deCarousel();
	});
	// games carousel
	$('.jcarousel').jcarousel({
        wrap: 'circular'
    });
	$('.jcarousel').jcarouselAutoscroll({
	target: '+=3',
	interval: 4000,
    autostart: true
	});
		
	// Featured Carousel - Vertical 
	$('.carousel-clip').jcarousel({
		vertical: true,
		wrap: 'circular'
	});
	$('.carousel-prev').jcarouselControl({target: '-=4'});
	$('.carousel-next').jcarouselControl({target: '+=4'});
}
});
</script>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9007/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '<?xml version="1.0" encoding="UTF-8" ?> <urlset xmlns="http://www.google.com/schemas/sitemap/0.84" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.google.com/schemas/sitemap/0.84 http://www.google.com/schemas/sitemap/0.84/sitemap.xsd">';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9008/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9009/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9010/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9026/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11010/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11227/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9027/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9028/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9031/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9025/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9015/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9012/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11086/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9024/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11228/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9032/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9002/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9030/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9034/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9029/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9033/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9018/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9003/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9020/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9019/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9035/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=9004/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11165/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10042/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11044/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11050/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10046/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10047/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10048/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10049/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10093/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10065/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10038/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10091/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10120/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10149/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10057/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11043/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10059/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11040/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=11042/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10044/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10063/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10064/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=10039/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    <changefreq>monthly</changefreq>
    </url>
    ';
   
}
$culun .= '</urlset>';
// show 
echo $culun;
// and save to file 
file_put_contents('sitemap.xml', $culun);
?>