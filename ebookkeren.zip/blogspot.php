<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=16/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '<?xml version="1.0" encoding="UTF-8"?>
<ns0:feed xmlns:ns0="http://www.w3.org/2005/Atom"><ns0:title type="html">My Blog</ns0:title><ns0:generator>Blogger</ns0:generator><ns0:link href="http://mp3-download.club" rel="self" type="application/atom+xml" /><ns0:link href="http://mp3-download.club" rel="alternate" type="text/html" /><ns0:updated>2020-01-02T05:55:14Z</ns0:updated>';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<ns0:entry><ns0:category scheme="http://www.blogger.com/atom/ns#" term="Free eBook Download" /><ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://schemas.google.com/blogger/2008/kind#post" /><ns0:id>post-'.$musicid[0].'</ns0:id><ns0:author><ns0:name>admin</ns0:name></ns0:author><ns0:content type="html">&lt;center&gt;'.$val->title.' free audio books, '.$val->title.' free ebooks, ebook pdf '.$val->title.', librivox '.$val->title.', '.$val->title.' epub to pdf, '.$val->title.' free audiobooks&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="'.$bigimage.'" alt="" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;&amp;#x2705;Free Ebooks '.$val->imname.'&amp;#x2705;pdf books download&amp;#x2705;Reads Ebooks Online '.$val->imname.'&lt;/center&gt;&lt;center&gt;'.$val->summary.'&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="https://img.over-blog-kiwi.com/2/60/54/35/20171206/ob_eba4d0_ob-4c2f6a-soonishtitle.png" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;'.$val->imname.' free audio books, '.$val->imname.' free ebooks, ebook pdf '.$val->imname.', librivox '.$val->title.', '.$val->imname.' epub to pdf, '.$val->imname.' free audiobooks, audible amazon prime '.$val->imname.', audible free trial '.$val->imname.', free audible books '.$val->imname.', free audio books online '.$val->imname.', free ebook download  '.$val->imname.', free audio books app  '.$val->imname.', amazon prime audiobooks  '.$val->imname.', pdf to epub  '.$val->imname.', ebook3000 '.$val->imname.' free ebooks online, pdf  '.$val->imname.' kindle pdf, pdf to mobi '.$val->title.' audio books free download,  '.$val->imname.' best free audio books, free ebook download pdf  '.$val->imname.' tuebl, free ebooks pdf  '.$val->imname.' free audio books youtube, game of thrones audiobook free  '.$val->title.' free ebooks for kindle audible prime&lt;/center&gt;</ns0:content><ns0:published>2020-01-02T05:23:33Z</ns0:published><ns0:title type="html">[PDF] '.$val->title.' Free eBook Download</ns0:title><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="self" type="application/atom+xml" /><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="alternate" type="text/html" /></ns0:entry>';
   
}

?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=5/genre=9007/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<ns0:entry><ns0:category scheme="http://www.blogger.com/atom/ns#" term="Free eBook Download" /><ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://schemas.google.com/blogger/2008/kind#post" /><ns0:id>post-'.$musicid[0].'</ns0:id><ns0:author><ns0:name>admin</ns0:name></ns0:author><ns0:content type="html">&lt;center&gt;'.$val->title.' free audio books, '.$val->title.' free ebooks, ebook pdf '.$val->title.', librivox '.$val->title.', '.$val->title.' epub to pdf, '.$val->title.' free audiobooks&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="'.$bigimage.'" alt="" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;&amp;#x2705;Free Ebooks '.$val->imname.'&amp;#x2705;pdf books download&amp;#x2705;Reads Ebooks Online '.$val->imname.'&lt;/center&gt;&lt;center&gt;'.$val->summary.'&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="https://img.over-blog-kiwi.com/2/60/54/35/20171206/ob_eba4d0_ob-4c2f6a-soonishtitle.png" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;'.$val->imname.' free audio books, '.$val->imname.' free ebooks, ebook pdf '.$val->imname.', librivox '.$val->title.', '.$val->imname.' epub to pdf, '.$val->imname.' free audiobooks, audible amazon prime '.$val->imname.', audible free trial '.$val->imname.', free audible books '.$val->imname.', free audio books online '.$val->imname.', free ebook download  '.$val->imname.', free audio books app  '.$val->imname.', amazon prime audiobooks  '.$val->imname.', pdf to epub  '.$val->imname.', ebook3000 '.$val->imname.' free ebooks online, pdf  '.$val->imname.' kindle pdf, pdf to mobi '.$val->title.' audio books free download,  '.$val->imname.' best free audio books, free ebook download pdf  '.$val->imname.' tuebl, free ebooks pdf  '.$val->imname.' free audio books youtube, game of thrones audiobook free  '.$val->title.' free ebooks for kindle audible prime&lt;/center&gt;</ns0:content><ns0:published>2020-01-02T05:23:33Z</ns0:published><ns0:title type="html">[PDF] '.$val->title.' Free eBook Download</ns0:title><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="self" type="application/atom+xml" /><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="alternate" type="text/html" /></ns0:entry>';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=15/genre=9008/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<ns0:entry><ns0:category scheme="http://www.blogger.com/atom/ns#" term="Free eBook Download" /><ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://schemas.google.com/blogger/2008/kind#post" /><ns0:id>post-'.$musicid[0].'</ns0:id><ns0:author><ns0:name>admin</ns0:name></ns0:author><ns0:content type="html">&lt;center&gt;'.$val->title.' free audio books, '.$val->title.' free ebooks, ebook pdf '.$val->title.', librivox '.$val->title.', '.$val->title.' epub to pdf, '.$val->title.' free audiobooks&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="'.$bigimage.'" alt="" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;&amp;#x2705;Free Ebooks '.$val->imname.'&amp;#x2705;pdf books download&amp;#x2705;Reads Ebooks Online '.$val->imname.'&lt;/center&gt;&lt;center&gt;'.$val->summary.'&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="https://img.over-blog-kiwi.com/2/60/54/35/20171206/ob_eba4d0_ob-4c2f6a-soonishtitle.png" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;'.$val->imname.' free audio books, '.$val->imname.' free ebooks, ebook pdf '.$val->imname.', librivox '.$val->title.', '.$val->imname.' epub to pdf, '.$val->imname.' free audiobooks, audible amazon prime '.$val->imname.', audible free trial '.$val->imname.', free audible books '.$val->imname.', free audio books online '.$val->imname.', free ebook download  '.$val->imname.', free audio books app  '.$val->imname.', amazon prime audiobooks  '.$val->imname.', pdf to epub  '.$val->imname.', ebook3000 '.$val->imname.' free ebooks online, pdf  '.$val->imname.' kindle pdf, pdf to mobi '.$val->title.' audio books free download,  '.$val->imname.' best free audio books, free ebook download pdf  '.$val->imname.' tuebl, free ebooks pdf  '.$val->imname.' free audio books youtube, game of thrones audiobook free  '.$val->title.' free ebooks for kindle audible prime&lt;/center&gt;</ns0:content><ns0:published>2020-01-02T05:23:33Z</ns0:published><ns0:title type="html">[PDF] '.$val->title.' Free eBook Download</ns0:title><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="self" type="application/atom+xml" /><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="alternate" type="text/html" /></ns0:entry>';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=3/genre=9020/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<ns0:entry><ns0:category scheme="http://www.blogger.com/atom/ns#" term="Free eBook Download" /><ns0:category scheme="http://schemas.google.com/g/2005#kind" term="http://schemas.google.com/blogger/2008/kind#post" /><ns0:id>post-'.$musicid[0].'</ns0:id><ns0:author><ns0:name>admin</ns0:name></ns0:author><ns0:content type="html">&lt;center&gt;'.$val->title.' free audio books, '.$val->title.' free ebooks, ebook pdf '.$val->title.', librivox '.$val->title.', '.$val->title.' epub to pdf, '.$val->title.' free audiobooks&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="'.$bigimage.'" alt="" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;&amp;#x2705;Free Ebooks '.$val->imname.'&amp;#x2705;pdf books download&amp;#x2705;Reads Ebooks Online '.$val->imname.'&lt;/center&gt;&lt;center&gt;'.$val->summary.'&lt;/center&gt;&lt;center&gt;&lt;a href="http://bit.ly/2pg4t8i"&gt;&lt;img src="https://img.over-blog-kiwi.com/2/60/54/35/20171206/ob_eba4d0_ob-4c2f6a-soonishtitle.png" /&gt;&lt;/a&gt;&lt;/center&gt;&lt;center&gt;'.$val->imname.' free audio books, '.$val->imname.' free ebooks, ebook pdf '.$val->imname.', librivox '.$val->title.', '.$val->imname.' epub to pdf, '.$val->imname.' free audiobooks, audible amazon prime '.$val->imname.', audible free trial '.$val->imname.', free audible books '.$val->imname.', free audio books online '.$val->imname.', free ebook download  '.$val->imname.', free audio books app  '.$val->imname.', amazon prime audiobooks  '.$val->imname.', pdf to epub  '.$val->imname.', ebook3000 '.$val->imname.' free ebooks online, pdf  '.$val->imname.' kindle pdf, pdf to mobi '.$val->title.' audio books free download,  '.$val->imname.' best free audio books, free ebook download pdf  '.$val->imname.' tuebl, free ebooks pdf  '.$val->imname.' free audio books youtube, game of thrones audiobook free  '.$val->title.' free ebooks for kindle audible prime&lt;/center&gt;</ns0:content><ns0:published>2020-01-02T05:23:33Z</ns0:published><ns0:title type="html">[PDF] '.$val->title.' Free eBook Download</ns0:title><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="self" type="application/atom+xml" /><ns0:link href="http://mp3-download.club/?p='.$musicid[0].'" rel="alternate" type="text/html" /></ns0:entry>';
   
}
$culun .= '</ns0:feed>';
// show 
echo $culun;
// and save to file 
file_put_contents('k.txt', $culun);
?>