<?php include('siteconfig.php'); ?>
<?php
function cano($s){
	$s = $output = trim(preg_replace(array("`'`", "`[^a-z0-9]+`"),  array("", "-"), strtolower($s)), "-");
	return $s;
}
?> 

<script>
jQuery(document).ready(function($){
if(jQuery().jcarousel) {
	// Featured Carousel - Horizontal 
	$(window).bind('load resize', function(){
		
		$('.fcarousel-6').deCarousel();
		$('.fcarousel-5').deCarousel();
	});
	// games carousel
	$('.jcarousel').jcarousel({
        wrap: 'circular'
    });
	$('.jcarousel').jcarouselAutoscroll({
	target: '+=3',
	interval: 4000,
    autostart: true
	});
		
	// Featured Carousel - Vertical 
	$('.carousel-clip').jcarousel({
		vertical: true,
		wrap: 'circular'
	});
	$('.carousel-prev').jcarouselControl({target: '-=4'});
	$('.carousel-next').jcarouselControl({target: '+=4'});
}
});
</script>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10128/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10129/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10130/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10131/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10132/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10133/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10134/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10135/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10136/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10137/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10138/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10139/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10140/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10141/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10142/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10143/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10144/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10145/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10146/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10147/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10148/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=10149/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11010/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11011/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11012/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11013/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11014/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11015/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11016/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11017/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11019/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11020/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11021/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11022/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11023/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11024/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11025/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11026/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11027/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11028/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11029/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11030/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11031/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11032/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11033/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11034/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11035/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11036/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11037/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
?>
<?php
$string = file_get_contents('https://itunes.apple.com/de/rss/toppaidebooks/limit=200/genre=11038/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
	$val->updated = ( $val->updated);
	
    $culun .= '
    <url>
    <loc>'.$site_url.'/book/'.$musicid[0].'/'.cano($val->imname).'</loc>
    <lastmod>'.$val->updated.'</lastmod>
    </url>
    ';
   
}
$culun .= '</urlset>';
// show 
echo $culun;
// and save to file 
file_put_contents('sitemap_04.xml', $culun);
?>