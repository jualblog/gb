<?php
$string = file_get_contents("https://itunes.apple.com/es/rss/toppaidebooks/limit=200/xml", "https://itunes.apple.com/es/rss/toppaidebooks/limit=200/genre=9007/xml");
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<html><center>
    <p><h1><b>[PDF] '.$val->title.' Descarga De Libros Gratis<b></h1></p>
    <p>'.$val->title.' libros gratis xyz, '.$val->title.' libros gratis xd '.$val->title.', libros gratis para kindle '.$val->title.', '.$val->title.' epub libros, '.$val->title.' descargar libros</p>
    <a href="http://bit.ly/2pg4t8i"><img src="'.$bigimage.'" alt=""></a>
    <p>✅Ebooks gratis'.$val->imname.'✅descarga de libros pdf✅Lee libros electrónicos en línea '.$val->imname.'</p>
    <p>'.$val->summary.'</p>
    <a href="http://bit.ly/2pg4t8i"><img src="https://1.bp.blogspot.com/-KjTUU9UfSEw/Xg94VKrvIBI/AAAAAAAAAEM/gC05T6yVDBIu_cnPdIdL_tplG_Z8819UgCNcBGAsYHQ/s1600/Epub.png"/></a> <a href="http://bit.ly/2pg4t8i"><img src="https://1.bp.blogspot.com/--ilpy84Fi1w/Xg94VEfCIxI/AAAAAAAAAEQ/sJk9mlto4sMb5vFUfKOvEfCHenmbBBhxwCNcBGAsYHQ/s1600/Online.png"/></a>

    <p>'.$val->imname.' libros epub, '.$val->imname.' libros para leer online, '.$val->imname.' epub libros, '.$val->imname.' libros kindle gratis, '.$val->imname.' libros completos pdf, '.$val->imname.' libros electronicos gratis, '.$val->imname.' libros gratis para kindle, '.$val->imname.' libros ebook gratis, '.$val->imname.' libros mobi, '.$val->imname.' bajar libros, '.$val->imname.' descarga de libros, '.$val->imname.' libros xd gratis, '.$val->imname.' sophie saint rose libros, '.$val->imname.' paginas descargar libros, '.$val->imname.' papyrefb2net descargar libros, </p>

<p>libros para leer online gratis '.$val->imname.', libros pdf español '.$val->imname.', libros mobi gratis '.$val->imname.', libros pdf gratis mundo '.$val->imname.', mejores paginas para descargar libros '.$val->imname.', penelope sky libros '.$val->imname.', libros gratis xyz no funciona '.$val->imname.', libros gratis xyz policiaca '.$val->imname.', libros gratis sin registrarse '.$val->imname.', isabel keats libros '.$val->imname.', xyz descargar libros '.$val->imname.', libros gratis para ebook '.$val->imname.', libros completos pdf gratis '.$val->imname.', libros sophie saint rose '.$val->imname.', libros online pdf '.$val->imname.', </p>

<p>'.$val->imname.' libros de lectura en ingles pdf, '.$val->imname.' libros en epub, '.$val->imname.' libros gratis pdf sin registrarse, '.$val->imname.' libros pdf gratis en español, '.$val->imname.' libros de sophie saint rose, '.$val->imname.' libros menage trois pdf, '.$val->imname.' libros romanticos pdf gratis, '.$val->imname.' libros de sophie saint rose para descargar gratis, '.$val->imname.' libros gratis para leer ahora, '.$val->imname.' libros gratis xyz facebook, '.$val->imname.' loles lopez libros, '.$val->imname.' jana aston libros, '.$val->imname.' sarah maclean libros, '.$val->imname.' descarga de libros electronicos, '.$val->imname.' libros gratis epub para descargar programa para leer libros libros bianca pdf, </center></html><p>--------------------------------------------------------------------------------------------------------------------------------------------------</p>';
   
}
$culun .= '';
// show 
echo $culun;
// and save to file 
file_put_contents('z.txt', $culun);
?>
