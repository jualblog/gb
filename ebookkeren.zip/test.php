<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=romance/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<html><center>
    <p><h1><b>[PDF] '.$val->title.' Free eBook Download<b></h1></p>
    <p>'.$val->title.' free audio books, '.$val->title.' free ebooks, ebook pdf '.$val->title.', librivox '.$val->title.', '.$val->title.' epub to pdf, '.$val->title.' free audiobooks</p>
    <a href="http://bit.ly/2pg4t8i"><img src="'.$bigimage.'" alt=""></a>
    <p>✅Free Ebooks '.$val->imname.'✅pdf books download✅Reads Ebooks Online '.$val->imname.'</p>
    <p>'.$val->summary.'</p>
    <p><a href="http://bit.ly/2pg4t8i"><img style="max-width:100%; display: block; height:auto" src="https://img.over-blog-kiwi.com/2/60/54/35/20171206/ob_eba4d0_ob-4c2f6a-soonishtitle.png"/></a></p>

    <p>'.$val->imname.' free audio books, '.$val->imname.' free ebooks, ebook pdf '.$val->imname.', librivox '.$val->title.', '.$val->imname.' epub to pdf, '.$val->imname.' free audiobooks, audible amazon prime '.$val->imname.', audible free trial '.$val->imname.', free audible books '.$val->imname.', free audio books online '.$val->imname.', free ebook download  '.$val->imname.', free audio books app  '.$val->imname.', amazon prime audiobooks  '.$val->imname.', pdf to epub  '.$val->imname.', ebook3000 '.$val->imname.' free ebooks online, pdf  '.$val->imname.' kindle pdf, pdf to mobi '.$val->title.' audio books free download,  '.$val->imname.' best free audio books, free ebook download pdf  '.$val->imname.' tuebl, free ebooks pdf  '.$val->imname.' free audio books youtube, game of thrones audiobook free  '.$val->title.' free ebooks for kindle audible prime</p>

<p>free epub books '.$val->title.', azw3 to pdf '.$val->imname.', packtpub free '.$val->imname.', free audio books for kids '.$val->imname.', epub download '.$val->imname.', amazon prime ebooks '.$val->imname.', free audio books mp3 '.$val->imname.', amazon prime free audiobooks '.$val->imname.', free epub '.$val->imname.', kindle to pdf '.$val->imname.', free audiobooks reddit '.$val->imname.', planet ebook '.$val->title.', free audible credits '.$val->imname.', prime audiobooks '.$val->imname.', get free ebooks '.$val->imname.', librivox app '.$val->imname.', best free audiobook app '.$val->imname.', free ebook download sites without registration '.$val->imname.', libgen ebook '.$val->title.'</p>

<p>free ebooks reddit '.$val->title.', books on tape free '.$val->imname.', ebook777 '.$val->imname.', amazon free ebooks '.$val->imname.', audible free with prime '.$val->imname.', always and forever lara jean pdf '.$val->imname.', the algorithm design manual pdf '.$val->imname.', amazon prime and audible '.$val->title.', amazon prime audible books '.$val->imname.', free ibooks '.$val->imname.', ebooks free app '.$val->imname.', amazon free audio books '.$val->imname.', calculus early transcendentals 8th edition pdf reddit '.$val->imname.', amazon prime free ebooks '.$val->imname.', 100 deadly skills pdf '.$val->title.', audio books free download mp3 '.$val->imname.', packt free learning '.$val->imname.', cheap ebooks '.$val->imname.', free ebook download sites '.$val->title.', free ebooks for kids '.$val->imname.', all free ebooks '.$val->imname.'</center></html><p>--------------------------------------------------------------------------------------------------------------------------------------------------</p>';
   
}
$culun .= '';
// show 
echo $culun;
// and save to file 
file_put_contents('z.txt', $culun);
?>
<?php
$string = file_get_contents('https://itunes.apple.com/us/rss/toppaidebooks/limit=200/genre=books-arts-entertainment-film/xml');
// Remove the colon ":" in the <xxx:yyy> to be <xxxyyy>
$string = preg_replace("/(<\/?)(\w+):([^>]*>)/", "$1$2$3", $string);
$xml = simplexml_load_string($string);

// Output
$rssresults = '';
$culun .= '';

foreach ($xml->entry as $val) {
// edit foreach
	$musicid = $val->id;
	$musicid = str_replace("/id/","xxx",$musicid);
	$musicid=explode('/id',$musicid);
	$musicid=explode('?',$musicid[1]);
	// ssl images width="180px" height="180px"
	$sslimage = preg_replace('/http/ms', "http", $val->imimage[2]);
	$sslimage = preg_replace('/.mzstatic/ms', ".mzstatic", $sslimage);
	$bigimage = preg_replace('/170x170/ms', "300x300", $sslimage);
	// remove year from title
	$val->imname = preg_replace('@\(.*?\)@', '', $val->imname);
	$val->title = ( $val->title);
	$val->summary = ( $val->summary);
    $culun .= '<html><center>
    <p><h1><b>[PDF] '.$val->title.' Free eBook Download<b></h1></p>
    <p>'.$val->title.' free audio books, '.$val->title.' free ebooks, ebook pdf '.$val->title.', librivox '.$val->title.', '.$val->title.' epub to pdf, '.$val->title.' free audiobooks</p>
    <a href="http://bit.ly/2pg4t8i"><img src="'.$bigimage.'" alt=""></a>
    <p>✅Free Ebooks '.$val->imname.'✅pdf books download✅Reads Ebooks Online '.$val->imname.'</p>
    <p>'.$val->summary.'</p>
    <p><a href="http://bit.ly/2pg4t8i"><img style="max-width:100%; display: block; height:auto" src="https://img.over-blog-kiwi.com/2/60/54/35/20171206/ob_eba4d0_ob-4c2f6a-soonishtitle.png"/></a></p>

    <p>'.$val->imname.' free audio books, '.$val->imname.' free ebooks, ebook pdf '.$val->imname.', librivox '.$val->title.', '.$val->imname.' epub to pdf, '.$val->imname.' free audiobooks, audible amazon prime '.$val->imname.', audible free trial '.$val->imname.', free audible books '.$val->imname.', free audio books online '.$val->imname.', free ebook download  '.$val->imname.', free audio books app  '.$val->imname.', amazon prime audiobooks  '.$val->imname.', pdf to epub  '.$val->imname.', ebook3000 '.$val->imname.' free ebooks online, pdf  '.$val->imname.' kindle pdf, pdf to mobi '.$val->title.' audio books free download,  '.$val->imname.' best free audio books, free ebook download pdf  '.$val->imname.' tuebl, free ebooks pdf  '.$val->imname.' free audio books youtube, game of thrones audiobook free  '.$val->title.' free ebooks for kindle audible prime</p>

<p>free epub books '.$val->title.', azw3 to pdf '.$val->imname.', packtpub free '.$val->imname.', free audio books for kids '.$val->imname.', epub download '.$val->imname.', amazon prime ebooks '.$val->imname.', free audio books mp3 '.$val->imname.', amazon prime free audiobooks '.$val->imname.', free epub '.$val->imname.', kindle to pdf '.$val->imname.', free audiobooks reddit '.$val->imname.', planet ebook '.$val->title.', free audible credits '.$val->imname.', prime audiobooks '.$val->imname.', get free ebooks '.$val->imname.', librivox app '.$val->imname.', best free audiobook app '.$val->imname.', free ebook download sites without registration '.$val->imname.', libgen ebook '.$val->title.'</p>

<p>free ebooks reddit '.$val->title.', books on tape free '.$val->imname.', ebook777 '.$val->imname.', amazon free ebooks '.$val->imname.', audible free with prime '.$val->imname.', always and forever lara jean pdf '.$val->imname.', the algorithm design manual pdf '.$val->imname.', amazon prime and audible '.$val->title.', amazon prime audible books '.$val->imname.', free ibooks '.$val->imname.', ebooks free app '.$val->imname.', amazon free audio books '.$val->imname.', calculus early transcendentals 8th edition pdf reddit '.$val->imname.', amazon prime free ebooks '.$val->imname.', 100 deadly skills pdf '.$val->title.', audio books free download mp3 '.$val->imname.', packt free learning '.$val->imname.', cheap ebooks '.$val->imname.', free ebook download sites '.$val->title.', free ebooks for kids '.$val->imname.', all free ebooks '.$val->imname.'</center></html><p>--------------------------------------------------------------------------------------------------------------------------------------------------</p>';
   
}
$culun .= '';
// show 
echo $culun;
// and save to file 
file_put_contents('z.txt', $culun);
?>